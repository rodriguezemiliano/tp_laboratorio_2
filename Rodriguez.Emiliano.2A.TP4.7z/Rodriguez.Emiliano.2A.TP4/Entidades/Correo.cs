﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class Correo : IMostrar<List<Paquete>>
    {
        #region Atributos
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;
        #endregion

        #region Propiedades
        public List<Paquete> Paquetes
        {
            get
            {
                return this.paquetes;
            }
            set
            {
                this.paquetes = value;
            }
        }
        #endregion

        #region Constructores
        public Correo ()
        {
            this.Paquetes = new List<Paquete>();
            this.mockPaquetes = new List<Thread>();
        }
        #endregion
        #region Operadores
        public static Correo operator +(Correo correo, Paquete paquete)
        {
            foreach (Paquete item in correo.paquetes)
            {
                if (item == paquete)
                {
                    throw new TrackingIdRepetidoException();
                }
            }
            correo.paquetes.Add(paquete);
            Thread thread = new Thread(paquete.MockCicloDeVIda);
            correo.mockPaquetes.Add(thread);
            thread.Start();
            return correo;
        }
        #endregion
        #region Metodos
        public void FinEntregas()
        {
            foreach (Thread item in this.mockPaquetes)

            {
                item.Abort();
                
            }
        }

        public string MostrarDatos(IMostrar<List<Paquete>> elemento)
        {
            List<Paquete> paquetes = ((Correo)elemento).Paquetes;
            StringBuilder sb = new StringBuilder();

            foreach (Paquete item in paquetes)
            {
                sb.AppendLine(string.Format("{0} para {1} ({2}) \n", item.TrackingID, item.DireccionEntrega, item.Estado.ToString()));
            }

            return sb.ToString();
        }

        #endregion
    }
}
