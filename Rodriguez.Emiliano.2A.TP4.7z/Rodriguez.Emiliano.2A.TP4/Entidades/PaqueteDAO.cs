﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Entidades
{
    public static class PaqueteDAO
    {
        private static SqlCommand sqlCommand;
        private static SqlConnection sqlConnection;

        static PaqueteDAO()
        {
            sqlConnection = new SqlConnection();
            sqlCommand = new SqlCommand();
        }

        public static bool Insertar(Paquete paquete)
        {
            return true;
        }
    }
}
