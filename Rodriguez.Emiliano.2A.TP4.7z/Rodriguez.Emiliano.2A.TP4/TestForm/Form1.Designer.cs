﻿namespace TestForm
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblEstadoPaquetes = new System.Windows.Forms.Label();
            this.lblEstadoEntregado = new System.Windows.Forms.Label();
            this.lblEstadoEnViaje = new System.Windows.Forms.Label();
            this.lblEstadoIngresado = new System.Windows.Forms.Label();
            this.lblTrakingID = new System.Windows.Forms.Label();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.lblPaquete = new System.Windows.Forms.Label();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.lblostrarTodo = new System.Windows.Forms.Button();
            this.ltbIngresado = new System.Windows.Forms.ListBox();
            this.ltbEnViaje = new System.Windows.Forms.ListBox();
            this.lbiEntregado = new System.Windows.Forms.ListBox();
            this.cmsListas = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mostrarToolStripMenuItem = new System.Windows.Forms.ToolTip(this.components);
            this.mtxtTrackingiID = new System.Windows.Forms.MaskedTextBox();
            this.txtDireccion = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lblEstadoPaquetes
            // 
            this.lblEstadoPaquetes.AutoSize = true;
            this.lblEstadoPaquetes.Location = new System.Drawing.Point(34, 47);
            this.lblEstadoPaquetes.Name = "lblEstadoPaquetes";
            this.lblEstadoPaquetes.Size = new System.Drawing.Size(88, 13);
            this.lblEstadoPaquetes.TabIndex = 0;
            this.lblEstadoPaquetes.Text = "Estado Paquetes";
            // 
            // lblEstadoEntregado
            // 
            this.lblEstadoEntregado.AutoSize = true;
            this.lblEstadoEntregado.Location = new System.Drawing.Point(317, 75);
            this.lblEstadoEntregado.Name = "lblEstadoEntregado";
            this.lblEstadoEntregado.Size = new System.Drawing.Size(56, 13);
            this.lblEstadoEntregado.TabIndex = 1;
            this.lblEstadoEntregado.Text = "Entregado";
            // 
            // lblEstadoEnViaje
            // 
            this.lblEstadoEnViaje.AutoSize = true;
            this.lblEstadoEnViaje.Location = new System.Drawing.Point(176, 75);
            this.lblEstadoEnViaje.Name = "lblEstadoEnViaje";
            this.lblEstadoEnViaje.Size = new System.Drawing.Size(43, 13);
            this.lblEstadoEnViaje.TabIndex = 2;
            this.lblEstadoEnViaje.Text = "EnViaje";
            // 
            // lblEstadoIngresado
            // 
            this.lblEstadoIngresado.AutoSize = true;
            this.lblEstadoIngresado.Location = new System.Drawing.Point(34, 75);
            this.lblEstadoIngresado.Name = "lblEstadoIngresado";
            this.lblEstadoIngresado.Size = new System.Drawing.Size(54, 13);
            this.lblEstadoIngresado.TabIndex = 3;
            this.lblEstadoIngresado.Text = "Ingresado";
            this.lblEstadoIngresado.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblTrakingID
            // 
            this.lblTrakingID.AutoSize = true;
            this.lblTrakingID.Location = new System.Drawing.Point(446, 243);
            this.lblTrakingID.Name = "lblTrakingID";
            this.lblTrakingID.Size = new System.Drawing.Size(54, 13);
            this.lblTrakingID.TabIndex = 4;
            this.lblTrakingID.Text = "TrakingID";
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Location = new System.Drawing.Point(448, 289);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(52, 13);
            this.lblDireccion.TabIndex = 5;
            this.lblDireccion.Text = "Direccion";
            // 
            // lblPaquete
            // 
            this.lblPaquete.AutoSize = true;
            this.lblPaquete.Location = new System.Drawing.Point(446, 221);
            this.lblPaquete.Name = "lblPaquete";
            this.lblPaquete.Size = new System.Drawing.Size(47, 13);
            this.lblPaquete.TabIndex = 6;
            this.lblPaquete.Text = "Paquete";
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(560, 238);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 7;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // lblostrarTodo
            // 
            this.lblostrarTodo.Location = new System.Drawing.Point(560, 314);
            this.lblostrarTodo.Name = "lblostrarTodo";
            this.lblostrarTodo.Size = new System.Drawing.Size(75, 23);
            this.lblostrarTodo.TabIndex = 8;
            this.lblostrarTodo.Text = "MostrarTodo";
            this.lblostrarTodo.UseVisualStyleBackColor = true;
            this.lblostrarTodo.Click += new System.EventHandler(this.lblostrarTodo_Click);
            // 
            // ltbIngresado
            // 
            this.ltbIngresado.FormattingEnabled = true;
            this.ltbIngresado.Location = new System.Drawing.Point(37, 139);
            this.ltbIngresado.Name = "ltbIngresado";
            this.ltbIngresado.Size = new System.Drawing.Size(120, 95);
            this.ltbIngresado.TabIndex = 9;
            // 
            // ltbEnViaje
            // 
            this.ltbEnViaje.FormattingEnabled = true;
            this.ltbEnViaje.Location = new System.Drawing.Point(179, 139);
            this.ltbEnViaje.Name = "ltbEnViaje";
            this.ltbEnViaje.Size = new System.Drawing.Size(120, 95);
            this.ltbEnViaje.TabIndex = 10;
            // 
            // lbiEntregado
            // 
            this.lbiEntregado.FormattingEnabled = true;
            this.lbiEntregado.Location = new System.Drawing.Point(320, 139);
            this.lbiEntregado.Name = "lbiEntregado";
            this.lbiEntregado.Size = new System.Drawing.Size(120, 95);
            this.lbiEntregado.TabIndex = 11;
            this.lbiEntregado.SelectedIndexChanged += new System.EventHandler(this.lbiEntregado_SelectedIndexChanged);
            // 
            // cmsListas
            // 
            this.cmsListas.Name = "cmsListas";
            this.cmsListas.Size = new System.Drawing.Size(61, 4);
            this.cmsListas.Text = "Listas";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(39, 289);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(403, 116);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // mostrarToolStripMenuItem
            // 
            this.mostrarToolStripMenuItem.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
            // 
            // mtxtTrackingiID
            // 
            this.mtxtTrackingiID.Location = new System.Drawing.Point(449, 266);
            this.mtxtTrackingiID.Name = "mtxtTrackingiID";
            this.mtxtTrackingiID.Size = new System.Drawing.Size(94, 20);
            this.mtxtTrackingiID.TabIndex = 14;
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(446, 309);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(100, 28);
            this.txtDireccion.TabIndex = 15;
            this.txtDireccion.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 525);
            this.Controls.Add(this.txtDireccion);
            this.Controls.Add(this.mtxtTrackingiID);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbiEntregado);
            this.Controls.Add(this.ltbEnViaje);
            this.Controls.Add(this.ltbIngresado);
            this.Controls.Add(this.lblostrarTodo);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.lblPaquete);
            this.Controls.Add(this.lblDireccion);
            this.Controls.Add(this.lblTrakingID);
            this.Controls.Add(this.lblEstadoIngresado);
            this.Controls.Add(this.lblEstadoEnViaje);
            this.Controls.Add(this.lblEstadoEntregado);
            this.Controls.Add(this.lblEstadoPaquetes);
            this.Name = "Form1";
            this.Text = "Correo UTN por Rodriguez.Emiliano.2A.TP4";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEstadoPaquetes;
        private System.Windows.Forms.Label lblEstadoEntregado;
        private System.Windows.Forms.Label lblEstadoEnViaje;
        private System.Windows.Forms.Label lblEstadoIngresado;
        private System.Windows.Forms.Label lblTrakingID;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.Label lblPaquete;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button lblostrarTodo;
        private System.Windows.Forms.ListBox ltbIngresado;
        private System.Windows.Forms.ListBox ltbEnViaje;
        private System.Windows.Forms.ListBox lbiEntregado;
        private System.Windows.Forms.ContextMenuStrip cmsListas;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolTip mostrarToolStripMenuItem;
        private System.Windows.Forms.MaskedTextBox mtxtTrackingiID;
        private System.Windows.Forms.RichTextBox txtDireccion;
    }
}

