﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace TestForm
{
    public partial class Form1 : Form
    {
        private Correo correo;

        public Form1()
        {
            InitializeComponent();
            correo = new Correo();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete paquete = new Paquete(this.txtDireccion.Text, this.mtxtTrackingiID.Text);

            try
            {
                correo += paquete;
            }
            catch(TrackingIdRepetidoException ex)
            {
                MessageBox.Show(ex.Message);
            }
            paquete.InformarEstado += this.paq_InformaEstado;
            ActualizarEstado();
            
           
        }
        private void ActualizarEstado()
        {
            this.lbiEntregado.Items.Clear();
            this.ltbEnViaje.Items.Clear();
            this.lbiEntregado.Items.Clear();

            foreach (Paquete item in correo.Paquetes)
            {
                switch (item.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        this.ltbIngresado.Items.Add( item.MostrarDatos((IMostrar<List<Paquete>>)correo));
                        this.ltbEnViaje.Items.Clear();
                        
                        break;
                    case Paquete.EEstado.EnViaje:
                        this.ltbIngresado.Items.Clear();
                        this.ltbEnViaje.Items.Add( item.MostrarDatos((IMostrar<List<Paquete>>)correo));
                        
                        break;
                    case Paquete.EEstado.Entregado:
                        this.ltbIngresado.Items.Clear();
                        this.ltbEnViaje.Items.Clear();
                        this.lbiEntregado.Items.Add(item.MostrarDatos((IMostrar<List<Paquete>>)correo));
                        break;
                    default:
                        break;
                }
            }
           
        }
        public void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(d, new object[] { sender, e} );
            }
            else
            {
                ActualizarEstado();
            }
        }

        private void lblostrarTodo_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
        }

        private void MostrarInformacion<T>(IMostrar<T> correo)
        {
            if (correo != null)
            {
                this.groupBox1.Text += correo.MostrarDatos((IMostrar<List<Paquete>>)correo);
                this.lbiEntregado.Items.Clear();
                this.ltbEnViaje.Items.Clear();
                this.lbiEntregado.Items.Clear();
                this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lbiEntregado.SelectedItem);
            }
            
        }

        private void lbiEntregado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
   
}
