﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Excepciones;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {

        public bool Guardar(string archivo, string dato)
        {
            bool retorno = false;
            try
            {
                using (StreamWriter writer = new StreamWriter(archivo))
                {
                    writer.Write(dato);
                    retorno = true;
                }

            }
           catch(Exception e)
            {
                throw new ArchivosException(e);
            }
            
            return retorno;
        }

        public bool Leer(string archivo, out string dato)
        {
            bool retorno = false;

            using (StreamReader reader = new StreamReader("Jornada.txt"))
            {
                dato = reader.ReadLine();
            }
            return retorno;
        }
             
    }
}
