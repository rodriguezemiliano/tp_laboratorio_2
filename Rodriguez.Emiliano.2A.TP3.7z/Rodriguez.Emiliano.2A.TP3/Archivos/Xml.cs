﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using Excepciones;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        public bool Guardar(string archivo, T dato)
        {
            bool retorno = false;

            try
            {
                XmlSerializer serializador = new XmlSerializer(typeof(T));
                using (TextWriter writer = new StreamWriter(archivo))
                {
                    serializador.Serialize(writer, dato);
                    retorno = true;
                }
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }

        public bool Leer(string archivo, out T dato)
        {

            bool retorno = false;

            try
            {
                XmlSerializer serializador = new XmlSerializer(typeof(T));
                using ( TextReader writer = new StreamReader(archivo))
                {
                    dato = (T)serializador.Deserialize(writer);
                    retorno = true;
                }
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }
        

    }
}
