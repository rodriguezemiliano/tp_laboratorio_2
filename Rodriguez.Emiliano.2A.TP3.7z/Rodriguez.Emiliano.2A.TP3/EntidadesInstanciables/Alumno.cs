﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;
using System.Xml;
using System.Xml.Serialization;


namespace EntidadesInstanciables
{
    [XmlInclude(typeof(Universitario))]
    [XmlInclude(typeof(Alumno))]

    public class Alumno : Universitario
    {
        public enum EEstadoCuenta { AlDia, Deudor, Becado }

        private Universidad.EClases claseQueToma;
        private EEstadoCuenta estadoCuenta;

        #region constructores
        public Alumno()
        {

        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma) : base(id,nombre,apellido,dni,nacionalidad)
        {
            this.claseQueToma = claseQueToma;
        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoCuenta) : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this.estadoCuenta = estadoCuenta;
        }
        #endregion

        #region metodos

        protected override string MostrarDatos()
        {
            return base.MostrarDatos() + " ESTADO DE CUENTA: " +  this.estadoCuenta.ToString() + "\n" + this.ParticiparEnClase();
        }

        protected override string ParticiparEnClase()
        {
            return "TOMA CLASE DE:  " + this.claseQueToma.ToString() + " \n <------------------------------------------> \n";
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }

        #endregion

        #region Operadores
        public static bool operator ==(Alumno alumno, Universidad.EClases clase)
        {
            return (alumno.claseQueToma == clase && alumno.estadoCuenta != EEstadoCuenta.Deudor);
        }

        public static bool operator !=(Alumno alumno, Universidad.EClases clase)
        {
            return !(alumno == clase);
        }

        #endregion

    }
}
