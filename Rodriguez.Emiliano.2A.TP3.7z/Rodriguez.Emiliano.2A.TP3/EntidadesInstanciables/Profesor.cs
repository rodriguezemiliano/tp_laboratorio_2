﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;
using System.Xml;
using System.Xml.Serialization;

namespace EntidadesInstanciables
{
    [XmlInclude(typeof(Universitario))]
    [XmlInclude(typeof(Profesor))]

    public class Profesor : Universitario
    {
        private Queue<Universidad.EClases> ClasesDelDia;
        private static Random random;

        static Profesor()
        {
            Profesor.random = new Random();
        }
        public Profesor()
        {
            ClasesDelDia = new Queue<Universidad.EClases>();

        }
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
        {

            
            this._randomClases();
        }
        private void _randomClases()
        {
            ClasesDelDia = new Queue<Universidad.EClases>();
            this.ClasesDelDia.Enqueue((Universidad.EClases)random.Next(0, 3));
            this.ClasesDelDia.Enqueue((Universidad.EClases)random.Next(0, 3));
        }

        #region Operadores
        public static bool operator ==(Profesor profesor, Universidad.EClases clase)
        {
            bool retorno = false;

            foreach (Universidad.EClases item in profesor.ClasesDelDia)
            {
                if (item == clase)
                {
                    retorno = true;
                }
            }

            return retorno;
        }
        public static bool operator !=(Profesor profesor, Universidad.EClases clase)
        {
            return !(profesor == clase);
        }
        #endregion

        #region Metodos
        protected override string MostrarDatos()
        {
            return base.MostrarDatos() + " CLASES DEL DIA: \n " + ParticiparEnClase();
        }

        protected override string ParticiparEnClase()
        {
            string retorno = "";

            foreach (Universidad.EClases item in this.ClasesDelDia)
            {
                retorno += item.ToString() + "\n";
            }
            return retorno;
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }
        #endregion
    }
}
