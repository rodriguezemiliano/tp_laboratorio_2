﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Archivos;

namespace EntidadesInstanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;



        private Jornada()
        {
            this.Alumnos = new List<Alumno>();
        }

        public Jornada(Universidad.EClases clase, Profesor instructor) : this()
        {
            this.Clase = clase;
            this.Instructor = instructor;
        }

        #region Propiedades

        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }
            set
            {
                this.alumnos = value;
            }
        }
        public Universidad.EClases Clase
        {
            get
            {
                return this.clase;
            }
            set
            {
                this.clase = value;
            }
        }
        public Profesor Instructor
        {
            get
            {
                return this.instructor;
            }
            set
            {
                this.instructor = value;
            }
        }


        #endregion

        #region Operadores
        public static bool operator ==(Jornada jornada, Alumno alumno)
        {
            bool retorno = false;


            foreach (Alumno item in jornada.alumnos)
            {
                if (item == alumno)
                {
                    retorno = true;
                }
            }

            return retorno;
        }
        public static bool operator !=(Jornada jornada, Alumno alumno)
        {
            return !(jornada == alumno);
        }

        public static Jornada operator +(Jornada jornada, Alumno alumno)
        {
            if (jornada != alumno)
            {
                jornada.alumnos.Add(alumno);
            }
            return jornada;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Clase de " + this.clase.ToString() +" POR " + this.instructor.ToString() );
            
            
            retorno.Append("ALUMNOS: ");
            foreach (Alumno item in this.alumnos)
            {
                retorno.Append("- " + item.ToString() + "\n");
            }

            return retorno.ToString();
        }

        public static string Leer()
        {
            string retorno = "";

            Texto texto = new Texto();
            texto.Leer("Jornada.txt", out retorno);

            return retorno;
        }
        public static bool Guardar(Jornada jornada)
        {
            Texto texto = new Texto();
            texto.Guardar("C:\\tps\\Rodriguez.Emiliano.2A.TP3\\Jornada.txt", jornada.ToString());
            return true; 
        }
        #endregion
    }
}
