﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using EntidadesAbstractas;
using Archivos;

using Excepciones;

namespace EntidadesInstanciables
{
    [XmlInclude(typeof(Universidad))]

    public class Universidad
    {


        private List<Alumno> alumnos;
        private List<Profesor> profesores;
        private List<Jornada> jornadas;

        #region Propiedades
        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }

            set
            {
                this.alumnos = value;
            }
        }

        public List<Profesor> Profesores
        {
            get
            {
                return this.profesores;
            }

            set
            {
                this.profesores = value;
            }
        }

        public List<Jornada> Jornadas
        {
            get
            {
                return this.jornadas;
            }
            set
            {
                this.jornadas = value;
            }
        }

        public Jornada this[int i]
        {
            get
            {
                return this.jornadas[i];
            }
            set
            {
                this.jornadas[i] = value;
            }
        }
        #endregion

        #region Constructores

        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.profesores = new List<Profesor>();
            this.jornadas = new List<Jornada>();
        }

        #endregion

        #region Operadores
        public static bool operator ==(Universidad universidad, Alumno alumno)
        {
            bool retorno = false;

            foreach (Universitario item in universidad.Alumnos)
            {
                if (item == (Universitario)alumno)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }
        public static bool operator !=(Universidad universidad, Alumno alumno)
        {
            return !(universidad == alumno);
        }

        public static bool operator ==(Universidad universidad, Profesor profesor)
        {
            bool retorno = false;

            foreach (Alumno item in universidad.Alumnos)
            {
                if (item == profesor)
                {
                    retorno = true;
                }
            }

            return retorno;
        }
        public static bool operator !=(Universidad universidad, Profesor profesor)
        {
            return !(universidad == profesor);
        }

        public static Profesor operator ==(Universidad universidad, EClases clase)
        {
            Profesor retorno = new Profesor();
            bool flag = true;

            foreach (Profesor item in universidad.Profesores)
            {
                if (item == clase)
                {
                    retorno = item;
                    flag = false;
                    break;
                }
            }

            if (flag) throw new SinProfesorException();

            return retorno;
        }
        public static Profesor operator !=(Universidad universidad, EClases clase)
        {
            Profesor retorno;

            try
            {
                retorno = (universidad == clase);
            }
            catch (SinProfesorException e)
            {

                retorno = universidad.profesores[0];
            }

            return retorno;
        }

        public static Universidad operator +(Universidad universidad, Alumno alumno)
        {
            if (universidad.Alumnos.Count > 0)
            {
                if (universidad != alumno)
                {
                    universidad.alumnos.Add(alumno);
                }
                else throw new AlumnoRepetidoException();
            }
            else universidad.alumnos.Add(alumno);
           
         return universidad;
        }
        public static Universidad operator +(Universidad universidad, Profesor profesor)
        {
            if (universidad.Profesores.Count > 0)
            {
                if (universidad != profesor)
                {
                    universidad.profesores.Add(profesor);
                }
            }
            else universidad.Profesores.Add(profesor);
            
            return universidad;
        }

        public static Universidad operator +(Universidad universidad, EClases clase)
        {
            Jornada jornada;
            Profesor profesor = new Profesor();
            bool flag = false;

            foreach (Profesor item in universidad.profesores)
            {
                if (item == clase)
                {
                    profesor = item;
                    flag = true;
                    break;
                }

            }

            if (!flag) throw new SinProfesorException();

            jornada = new Jornada(clase,profesor);

            foreach (Alumno item in universidad.alumnos)
            {
                if (item == clase)
                {
                    jornada.Alumnos.Add(item);
                }
            }
            universidad.jornadas.Add(jornada);
            
            return universidad;
        }
        #endregion

        #region Metodos

        private static string MostrarDatos(Universidad universidad)
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("JORNADA: ");
            
            foreach (Jornada item in universidad.jornadas)
            {
                retorno.Append(item.ToString());
            }
            

            return retorno.ToString();
        }
        public override string ToString()
        {
            return Universidad.MostrarDatos(this);
        }
        public static bool Guardar(Universidad universidad)
        {
            bool retorno = false;

            Xml<Universidad> xml = new Xml<Universidad>();
            xml.Guardar("C:\\tps\\Rodriguez.Emiliano.2A.TP3\\Serializado.XML", universidad);
            
            return retorno;
        }

        #endregion

        public enum EClases { Programacion = 0, Laboratorio = 1, Legislacion = 2, SPD = 3 }
    }
}
