﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace EntidadesAbstractas
{
    
    public abstract class Persona
    {
        private string nombre;
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;

        #region constructores
        protected Persona()
        {
        }

        protected Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }

        protected Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre,apellido,nacionalidad)
        {
            this.Dni = dni;
        }

        protected Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }
        #endregion

        #region propiedades
        public string Nombre { get { return nombre; } set { this.nombre = this.ValidarNombreApellido(value); } }

        public string Apellido { get { return this.apellido; } set { this.apellido = this.ValidarNombreApellido(value); } }

        public int Dni
        {
            get { return dni; }

            set
            {
                this.dni = this.ValidarDni(this.nacionalidad, value);
            }

        }

        public string StringToDNI
        {
            set
            {

                this.Dni = this.ValidarDni(this.nacionalidad, value);
                       
                
            }
        }
        public ENacionalidad Nacionalidad { get { return nacionalidad; } set { this.nacionalidad = value; } }
        #endregion

        #region Metodos
        public override string ToString()
        {
            return this.Apellido + " " + this.Nombre + " " + this.Dni + " " + this.Nacionalidad;
        }
        

        public int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            int retorno = 0;

            if (nacionalidad == ENacionalidad.Argentino)
            {
                if (dato > 0 && dato < 89999999)
                {
                    retorno = dato;
                }
                else
                {
                    throw new NacionalidadInvalidaException();
                }
            }
            else
            {
                if (dato > 89999999 && dato < 99999999)
                {
                    retorno = dato;
                }
                else
                {
                    throw new NacionalidadInvalidaException();
                }
            }

            return retorno;
        }

        public int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int retorno = 0;

            if (!int.TryParse(dato, out retorno))
            {
                throw new DniInvalidoException();
            }
            else
            {
                retorno = retorno;
            }

            return retorno;

        }

        public string ValidarDni(string dato)
        {
            return this.ValidarDni(this.nacionalidad, dato).ToString();
        }

        public string ValidarNombreApellido(string dato)
        {
            string retorno = "";
            bool flag = false;

            foreach (char item in dato)
            {
                if (!char.IsLetter(item))
                {
                    flag = true;
                }
            }

            if (!flag)
            {
                retorno = dato;
            }
            return retorno;
        }
        #endregion
        public enum ENacionalidad { Argentino, Extranjero }
    }
}
