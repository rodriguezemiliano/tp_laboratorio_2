﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesAbstractas
{
    public abstract class Universitario : Persona
    {
        private int legajo;

        #region constructores

        public Universitario() : base()
        {
            this.Legajo = 0;
        }

        protected Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(apellido, nombre, dni, nacionalidad)
        {
            this.Legajo = legajo;
        }

        #endregion

        public int Legajo
        {
            get => legajo;
            set => legajo = value;
        }

        #region metodos

        protected virtual string MostrarDatos()
        {
            
            return string.Format("NOMBRE COMPLETO: {0} {1} \nNACIONALIDAD: {3} \n \nLEGAJO NUMERO: {2} \n", this.Nombre, this.Apellido, this.legajo, this.Nacionalidad);
        }

        public override bool Equals(object obj)
        {
            return (Universitario)obj == this;
        }

        protected abstract string ParticiparEnClase();

        #endregion

        #region operadores

        public static bool operator ==(Universitario u1, Universitario u2)
        {
            bool retorno = false;

            if (u1 is Universitario && u2 is Universitario && u1.Dni == u2.Dni || u1.legajo == u2.Legajo)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Universitario u1, Universitario u2)
        {
            return !(u1 == u2);
        }

        #endregion
    }
}
