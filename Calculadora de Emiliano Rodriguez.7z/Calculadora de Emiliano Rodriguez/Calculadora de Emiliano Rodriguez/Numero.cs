﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_de_Emiliano_Rodriguez
{
    public class Numero
    {
        #region Atributos

        private double _numero = 0;

        #endregion

        #region Constructores

        public Numero()
        {
            this._numero = 0;
        }
        public Numero(double numero)
        {
            this._numero = numero;
        }

        public Numero(string strNumero)
        {
            this.SetNumero = strNumero;
        }
        #endregion

        #region Propiedades 
        public string SetNumero
        {
            set { _numero = ValidarNumero(value); }
        }
        #endregion
                
        #region Operadores

        public static double operator + (Numero num1, Numero num2)
        {
            return num1._numero + num2._numero;
        }

        public static double operator -(Numero num1, Numero num2)
        {
            return num1._numero - num2._numero;
        }

        public static double operator /(Numero num1, Numero num2)
        {
            return num1._numero / num2._numero;
        }

        public static double operator *(Numero num1, Numero num2)
        {
            return num1._numero * num2._numero;
        }
        #endregion

        #region Metodos
        private double ValidarNumero(string strNumero)
        {
            double retorno ;

            if (!double.TryParse(strNumero, out retorno))
            {
                retorno = 0;
            }
                      
            return retorno;
        }
        public static string BinarioDecimal(string numero)
        {
            double retorno = 0;
            string parteEntera;
            string parteDecimal;
            int largo = numero.Length;
            int i;
            int exponte = 0;
            Boolean flag = false;

            //Busca la " , "
            for (i = 0; i < largo; i++)
            {
                if (numero[i].Equals(','))
                {
                    flag = true;
                    break;
                }
            }

            //Obtiene la parte entera del numero
            parteEntera = numero.Substring(0, i);
            
            //Transforma la parte entera del numero a binario y lo guarda en la variable de retorno
            for ( int c = parteEntera.Length - 1; c >= 0; c--)
            {
                if (parteEntera[c].Equals('1'))
                {
                    retorno += Math.Pow(2, exponte);
                }
                exponte++;
            }

            //Pregunta si encontro una ' , '
            if(flag == true)
            {
                exponte = 0;
                int a = numero.Length-2;
                parteDecimal = numero.Substring(i, numero.Length-i);

                //Transforma la parte decimal del numero a binario y lo suma a la variable de retorno
                for (int c = 0; c < parteDecimal.Length; c++)
                {
                    if (parteDecimal[c].Equals('1'))
                    {
                        retorno += 1 / Math.Pow(2, exponte);
                    }
                    exponte++;
                }

            }
            return retorno.ToString();//Convert.ToDecimal(numero).ToString();
        }
        public static string DecimalBinario(double numero)
        {
            string retorno = "";
            int parteEntera = (int) numero;
            double parteDecimal = numero - parteEntera;
            int auxParteDecimal = 0;
            Boolean flag = false;
            int contador = 0;
            
            //Obtiene en binario la parte entera del numero
            while (parteEntera  > 1)
            {
                retorno += (parteEntera % 2);
                parteEntera = parteEntera / 2;
            }

            //Agrego el ultimo 1 y lo ordeno al reves
            retorno += "1";
            char[] auxRetorno = retorno.ToCharArray();
            Array.Reverse(auxRetorno);
            retorno = new string(auxRetorno);

            //Obtiene tres digitos en binario de la parte decimal del numero y los concatena a la variable de retorno
            while (parteDecimal > 0.0 && contador < 3)
            {
                //Agrega el . al numero
                if (flag == false)
                {
                    retorno += ".";
                    flag = true;
                }

                parteDecimal = (parteDecimal * 2);
                auxParteDecimal = (int)parteDecimal;
                parteDecimal -= (int)parteDecimal;

                retorno += auxParteDecimal;
                contador++;
            }

            return retorno; // Convert.ToString((sbyte)numero, 2); ;
        }

        public static string DecimalBinario(string numero)
        {
            double auxNumero;
            string retorno;

            if (!double.TryParse(numero, out auxNumero))
            {
                retorno = "Valor Invalido";
            }
            else
            {
                retorno = Numero.DecimalBinario(auxNumero);
            }
            return retorno;
                
        }
        #endregion


    }
}
