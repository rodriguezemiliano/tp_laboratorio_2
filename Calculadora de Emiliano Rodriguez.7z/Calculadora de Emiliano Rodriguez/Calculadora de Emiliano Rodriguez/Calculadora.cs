﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_de_Emiliano_Rodriguez
{
    public static class Calculadora
    {
        #region Metodos

        public static double Operar(Numero num1, Numero num2, string operador)
        {
            double retorno = 0.0;

            switch (Calculadora.ValidarOperador(operador))
            {
                case "+":   retorno = num1 + num2;
                    break;

                case "-":   retorno = num1 - num2;
                    break;

                case "/":   retorno = num1 / num2;
                    break;

                case "*":   retorno = num1 * num2;
                    break;
                
            }

            return retorno;
        }

        public static string ValidarOperador(string operador)
        {
            string retorno = "+";
            string[] enumOperador = new string[4];

            /*
            enumOperador[0] = "+";
            enumOperador[1] = "-";
            enumOperador[2] = "/";
            enumOperador[3] = "*";
            */
            enumOperador.SetValue("+", 0);
            enumOperador.SetValue("-", 1);
            enumOperador.SetValue("/", 2);
            enumOperador.SetValue("*", 3);

            foreach (string item in enumOperador)
            {
                if (item.Equals(operador))
                {
                    retorno = operador;
                }
            }

            return retorno;
        }
        #endregion
    }
}
